#include<stdlib.h>
#include<stdio.h>
#include<string.h>

//creation des structures
typedef struct Voiture{
	int idVoiture;
	char marque[15];
	char nomVoiture[15];
	char couleur[7];
	int nbplaces;
	int prixJour;
	char Enlocation[17];
}voiture;
typedef struct date{
	int jour;
	int mois;
	int annee;
}date;
typedef struct contratLocation{
	float numContrat;
	int idVoiture;
	int idClient;
	date debut;
	date fin;
	int cout;
}contrat;
typedef struct Client{
	int idClient;
	char nom[20];
	char prenom[20];
	int cin;
	char adresse[15];
	int telephone;
}client;
/************MENU PRINCIPAL**************/
int menu(){
	int choix;
	system("cls");
	printf("\n                                  \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb\n");	
	printf("                                  \xba   Menu Patincipal   \xba \n");
	printf("                                  \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc\n");	
	printf("\n                      \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n                      \xba                                              \xba\n");
    printf("                      \xba    Location........................1         \xba\n");
	printf("                      \xba    Gestion voitures................2         \xba\n");
	printf("                      \xba    Gestion clients.................3         \xba\n");
	printf("                      \xba    Quitter.........................4         \xba\n");
	printf("                      \xba                                              \xba");
	printf("\n                      \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                    Votre choix: ");
	scanf("%d",&choix);
	return choix;
}
/************MENU GESTION VOITURE**************/
int gestionVoiture(){
	int choix;
	system("cls");
	printf("\n                                  \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb\n");	
	printf("                                  \xba   Gestion des voitures   \xba \n");
	printf("                                  \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc\n");
	printf("\n                      \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n                      \xba                                              \xba\n");
	printf("                      \xba       Listes des voitures..........1         \xba\n");
	printf("                      \xba       Ajouter une voiture..........2         \xba\n");
	printf("                      \xba       Modifier voiture.............3         \xba\n");
	printf("                      \xba       Supprimer voiture............4         \xba\n");
	printf("                      \xba       Retour.......................5         \xba\n");
	printf("                      \xba                                              \xba");
	printf("\n                      \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                    Votre choix: ");
	scanf("%d",&choix);
	return choix;	
}
/************MENU LOCATION**************/
int location(){
	int choix;
	system("cls");
	printf("\n                                \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb\n");	
	printf("                                \xba   Location d'une Voiture   \xba \n");
	printf("                                \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc\n");
	printf("\n                      \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n                      \xba                                              \xba\n");
	printf("                      \xba          Visualiser contrat........1         \xba\n");
	printf("                      \xba          Louer voiture.............2         \xba\n");
	printf("                      \xba          Retourner voiture.........3         \xba\n");
	printf("                      \xba          Modifier contrat..........4         \xba\n");
	printf("                      \xba          Supprimer contrat.........5         \xba\n");
	printf("                      \xba          Retour....................6         \xba\n");
    printf("                      \xba                                              \xba");
	printf("\n                      \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                    Votre choix: ");
	scanf("%d",&choix);
	return choix;	
}
/************MENU GESTION CLIENTS**************/
int gestionClient(){
	int choix;
	system("cls");
	printf("\n                                \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb\n");	
	printf("                                \xba    Gestion Des Clients   \xba \n");
	printf("                                \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc\n");
	printf("\n                      \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n                      \xba                                              \xba\n");
	printf("                      \xba          Listes des clients.........1        \xba\n");
	printf("                      \xba          Ajouter client.............2        \xba\n");
	printf("                      \xba          Modifier client............3        \xba\n");
	printf("                      \xba          Supprimer client...........4        \xba\n");
	printf("                      \xba          Retour.....................5        \xba\n");
	printf("                      \xba                                              \xba");
	printf("\n                      \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                    Votre choix: ");
	scanf("%d",&choix);
	return choix;	
}
//fonctions des menus
void quitter()
{
	exit(0);
}
void retour()
{
	int x;
	printf("\n\nTapper : 1- Pour retourner au menu \n");
    printf("         0- Pour quitter l'application");
    printf("\n              Votre choix: ");
    scanf("%d",&x);
	switch(x)
    {
    	case 1: break;
    	case 0: quitter();break;
    	default:;break; 
	}
}
/*La fonction suivante est une fonction qui retourne le nombre de jour entre 2 dates
(on supposons qu'il y a 30 jours dans tous les mois et 356j dans l'annee pour faciliter les calculs
-Utilisation: le calcul du cout 
-Principe : on calcul  le nombre de jour X entre date deb et 01/01/2000 puis Y entre date fin et 01/01/2000 .
Y-X nous donne le nombre de jours entre date deb et fin
*/
int nbrJ(date deb,date fin)
{
	int ecart1,ecart2;
	
	ecart1=(deb.annee-2000)*356+(deb.mois-1)*30+(deb.jour-1);
	ecart2=(fin.annee-2000)*356+(fin.mois-1)*30+(fin.jour-1);
	return ecart2-ecart1;
} 

//gestion voitures
void listeVoitures()
{  FILE *voitures=fopen("voitures.bin","rb") ;
   voiture voit;
   int i=1;
   system("cls");
   if(voitures != NULL){
   while (fread(&voit,sizeof(voiture),1,voitures) != 0)
   {
   	 printf(" \xba Voiture %d:\n",i);
     printf(" \xba ID de la voiture...: %d\n",voit.idVoiture);
     printf(" \xba Marque.............: %s\n",voit.marque);
     printf(" \xba Le nom.............: %s\n",voit.nomVoiture);
     printf(" \xba La couleur.........: %s\n",voit.couleur);
     printf(" \xba Nombre de places...: %d\n",voit.nbplaces);
     printf(" \xba Prix par jour......: %d\n",voit.prixJour);
     printf(" \xba En location........: %s\n\n",voit.Enlocation);
     i++;
    }
    }
    else 
     printf("Erreur d'ouverture du fichier!\n");
    fclose(voitures);
    retour();
}
void ajouterVoiture(){
	
	FILE *voitures= fopen ("voitures.bin", "ab+"); 
	voiture voit;
	system("cls");
	if(voitures != NULL){
	printf("********Saisir les informations :********\n");
	printf(" \xba ID voiture: ");
	scanf("%d",&voit.idVoiture);
	printf(" \xba La marque: ");
	scanf("%s",voit.marque);
	printf(" \xba Le nom de la voiture: ");
	scanf("%s",voit.nomVoiture);
	printf(" \xba La couleur: ");
	scanf("%s",voit.couleur);
	printf(" \xba La nombre de places: ");
	scanf("%d",&voit.nbplaces);
	printf(" \xba Prix par jour: ");
	scanf("%d",&voit.prixJour);
	printf(" \xba En location: ");
	scanf("%s",voit.Enlocation);
	fwrite(&voit,sizeof(voit),1,voitures);
	printf("\n\n\xbaLe nouvelle voiture a ete bien enregistree\n");
    }
    else 
     printf("Erreur d'ouverture du fichier!\n");
    fclose(voitures);
	retour();
}
void modifierVoiture()
{
	FILE *voitures=fopen("voitures.bin","rb");
	if(voitures==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	FILE *tmpv=fopen("tmpv.bin","wb");
	if(tmpv==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	
	FILE *contrats=fopen("contrats.bin","rb");//utiliser si on change le prix par jour pour mettre a jour le cout
	if(contrats==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	FILE *tmpc=fopen("tmpc.bin","wb");
	if(tmpc==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	contrat c;
	int id,trouve=0,x,w,n;
	voiture voit;
	system("cls");
	printf("******Saisir l'ID de la voiture dont vous voulez modifier les informations: ");
	scanf("%d",&id);
	while (fread(&voit,sizeof(voiture),1,voitures) != 0)
	{ 
		if(voit.idVoiture==id && trouve==0)
		{
			do{
			  printf("\nChoisir l'information que vous voulez modifier:\n");
              printf("1- La marque \n");	
	          printf("2- Le nom \n");
              printf("3- La couleur\n");
              printf("4- Le nombre de places \n");	
	          printf("5- Le prix par jour \n");
              printf("6- Retour\n");
              printf("  Votre choix: ");
              scanf("%d",&x);
              switch(x)
			   {
			  	case 1:
			  	  printf("\nSaisir la nouvelle marque : ");
			  	  scanf("%s",voit.marque);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix: ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	case 2:
			      printf("\nSaisir le nouveau nom : ");
			  	  scanf("%s",voit.nomVoiture);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix: ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	case 3:
			      printf("\nSaisir la nouvelle couleur : ");
			  	  scanf("%s",voit.couleur);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix: ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
				case 4:
			      printf("\nSaisir le nombre de places : ");
			  	  scanf("%d",&voit.nbplaces);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix: ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break; 
				case 5:
			      printf("\nSaisir le nouveau prix : ");
			  	  scanf("%d",&voit.prixJour);
			  	  //modification du cout
				  while (fread(&c,sizeof(c),1,contrats) != 0)
				  {
				  	if(c.idVoiture==voit.idVoiture){
				  		n=nbrJ(c.debut,c.fin);//nouveau nombre de jour
	          	        c.cout=n*voit.prixJour;
	          	        fwrite(&c,sizeof(c),1,tmpc); 
					  }
					else fwrite(&c,sizeof(c),1,tmpc);	
				  }
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix: ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break; 
			  	case 6:break;
			  	default:
				printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 6\n");
				system("pause");
				break;
			   }
              }while(x!=6);
              label:
              fwrite(&voit,sizeof(voit),1,tmpv);
              trouve=1;
	   }
	   else fwrite(&voit,sizeof(voit),1,tmpv);
    }
	fclose(tmpv);
    fclose(voitures);
    remove("voitures.bin");
    rename("tmpv.bin","voitures.bin");
    //fichier contrat
    fclose(tmpc);
    fclose(contrats);
    remove("contrats.bin");
    rename("tmpc.bin","contrats.bin");
    if(trouve==0){
	   printf("\nIl existe aucune voiture dont l'ID vaut %d\n",id);
    printf("\n\nTapper : 1- Pour essayer avec un autre ID \n");
    printf("         2- Pour retourner au menu \n");
    printf("         0- Pour quitter l'application");
    printf("\n              Votre choix: ");
    scanf("%d",&w);
	switch(w)
    {
    	case 1: modifierVoiture();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:break; 
	}}
	else{
	if(x!=6){//quant l'utilisateur choisi 6, c-a-d retour , on sort sans rien afficher
	printf("\n\xbaLes modifications ont ete bien effectuees\n");
	retour();
    }}
}
void SuppVoiture()
{
	FILE *voitures=fopen("voitures.bin","rb");
	if(voitures==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	FILE *tmp=fopen("tmp.bin","wb");
	if(tmp==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	int id,trouve=0,x;
	system("cls");
	voiture voit;
	printf("Saisir l'ID de la voiture que vous voulez supprimer: ");
	scanf("%d",&id);
	while (fread(&voit,sizeof(voiture),1,voitures) != 0)
		if(voit.idVoiture!=id)
		  fwrite(&voit,sizeof(voit),1,tmp);
		else trouve=1;
    fclose(tmp);
    fclose(voitures);
    remove("voitures.bin");
    rename("tmp.bin","voitures.bin");
    if(trouve==0)
	{
	   printf("\nIl existe aucune voiture dont l'ID vaut %d\n",id);
    	printf("\n\nTapper : 1- Pour essayer avec un autre ID \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&x);
		switch(x)
    	{
    	case 1: SuppVoiture();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
	else{
    printf("\n\xbaLa suppression a ete bien effectuee\n");
	retour();
	}	
}

//gestion clients
void listeClients()
{  
   FILE *clients=fopen("clients.bin","rb");
   client c;
   system("cls");
   int i=1;
   while (fread(&c,sizeof(client),1,clients) != 0)
   {
   	 printf(" \xba Client %d:\n",i);
     printf(" \xba ID du client...: %d\n",c.idClient);
     printf(" \xba Nom.............: %s\n",c.nom);
     printf(" \xba Prenom..........: %s\n",c.prenom);
     printf(" \xba CIN.............: %d\n",c.cin);
     printf(" \xba Adresse.........: %s\n",c.adresse);
     printf(" \xba Telephone.......: %d\n\n",c.telephone);
     i++;
    }
    fclose(clients);
    retour();
}
void ajouterClient(){
	
	FILE *clients=fopen("clients.bin","ab+") ;
	if(clients==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
    client c;
    system("cls");
	printf("********Saisir les informations :********\n");
	printf("ID du client: ");
	scanf("%d",&c.idClient);
	printf("Le nom: ");
	scanf("%s",c.nom);
	printf("Le prenom: ");
	scanf("%s",c.prenom);
	printf("cin: ");
	scanf("%d",&c.cin);
	printf("Adresse: ");
	scanf("%s",c.adresse);
	printf("telepphone: ");
	scanf("%d",&c.telephone);
	fwrite(&c,sizeof(client),1,clients);
	fclose(clients);
	printf("\n\xbaLe nouveau client a ete bien enregistre\n");
	retour();
}
void modifierClient()
{
	system("cls");
    FILE *clients=fopen("clients.bin","rb");
    if(clients==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	FILE *tmpc=fopen("tmpc.bin","wb");
	if(tmpc==0)
	{
		printf("Erreur d'overture du fichier!");
		retour();
	}
	int id,trouve=0,x,w;
	client c;
	printf("******Saisir l'ID du client dont vous voulez modifier les informations: ");
	scanf("%d",&id);
	while(fread(&c,sizeof(c),1,clients) != 0)
	{
	    if(c.idClient==id && trouve==0)
		{
			do
			{
			  printf("Choisir l'information que vous voulez modifier:\n");
              printf("1- Le nom \n");	
	          printf("2- Le prenom \n");
              printf("3- CIN \n");
              printf("4- L'adresse \n");	
	          printf("5- telephone \n");
              printf("6- Retour\n");
              printf("   Votre choix: ");
              scanf("%d",&x);
              switch(x)
			  {
			  	case 1:
			  	  printf("Saisir le nouveau nom : ");
			  	  scanf("%s",c.nom);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	case 2:
			      printf("Saisir le nouveau prenom : ");
			  	  scanf("%s",c.prenom);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON\n ");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	case 3:
			      printf("Saisir la nouveau CIN : ");
			  	  scanf("%d",&c.cin);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
				case 4:
			      printf("Saisir la nouvelle adresse : ");
			  	  scanf("%s",c.adresse);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
                  system("cls");		  	
			  	  break;
				case 5:
			      printf("Saisir le nouveau numero de telephone : ");
			  	  scanf("%d",&c.telephone);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break; 
			  	case 6:break;
			  	default : 
				printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 6\n");
				system("pause");
				break;	  	
	           }
		    }while(x>0 && x<6);
		    label:
			fwrite(&c,sizeof(c),1,tmpc);
		    trouve=1;	
		    	
		}
	    else fwrite(&c,sizeof(c),1,tmpc);
	}
	fclose(tmpc);
	fclose(clients);
	remove("clients.bin");
	rename("tmpc.bin","clients.bin");
	if(trouve==0){
	   printf("\nIl existe aucune client dont l'ID vaut %d\n",id);
    printf("\n\nTapper : 1- Pour essayer avec un autre ID \n");
    printf("         2- Pour retourner au menu \n");
    printf("         0- Pour quitter l'application");
    printf("\n              Votre choix: ");
    scanf("%d",&w);
	switch(w)
    {
    	case 1: modifierClient();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
	}
	}
	else{
	if(x!=6){//quant l'utilisateur choisi 6, c-a-d retour , on sort sans rien afficher
	printf("\n\xbaLes modification ont ete bien effectuees\n");
	retour();
	}}
}
void SuppClient()
{
	system("cls");
	FILE *clients=fopen("clients.bin","rb");
	FILE *tmp=fopen("tmp.bin","wb");
	int trouve=0,x,id;
	client c;
	printf("******Saisir l'ID du client que vous voulez supprimer: ");
	scanf("%d",&id);
	while (fread(&c,sizeof(client),1,clients) != 0)
		if(c.idClient!=id)
		  fwrite(&c,sizeof(c),1,tmp);
		else trouve=1;
    fclose(tmp);
    fclose(clients);
    remove("clients.bin");
    rename("tmp.bin","clients.bin");
    if(trouve==0){
	   printf("\nIl existe aucune client dont l'ID vaut %d\n",id);
    printf("\n\nTapper : 1- Pour essayer avec un autre ID \n");
    printf("         2- Pour retourner au menu \n");
    printf("         0- Pour quitter l'application");
    printf("\n              Votre choix: ");
    scanf("%d",&x);
	switch(x)
    {
    	case 1: SuppClient();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
	}}
	else{
    printf("\n\xbaLa suppression a ete bien effectuee\n");
	retour();
	}	
}
//Location
void VisualiserContrat()
{
	system("cls");
	FILE *contrats=fopen("contrats.bin","rb");
	contrat cnt;
	int trouve=0,x;
	float c;
	printf("Saisir le numero de contrat: ");
	scanf("%f",&c);
	while (fread(&cnt, sizeof(cnt), 1, contrats) != 0 && trouve==0)
	{
		if(cnt.numContrat==c)
		{
	        printf("\n\n \xba Le numero de contrat    : %.0f\n",cnt.numContrat);
        	printf(" \xba ID de la voiture        : %d\n",cnt.idVoiture);
	        printf(" \xba ID du client            :  %d\n",cnt.idClient);
        	printf(" \xba DEBUT                   :  %d/%d/%d\n",cnt.debut.jour,cnt.debut.mois,cnt.debut.annee);
        	printf(" \xba FIN                     : %d/%d/%d\n",cnt.fin.jour,cnt.fin.mois,cnt.fin.annee);
        	printf(" \xba Cout location           :   %d DH",cnt.cout);
        	trouve=1;
        }
    } 
	fclose(contrats);
    if(trouve==0){
        printf("Le numero de contrat saisi est invalide\n");
        printf("\n\nTapper : 1- Pour essayer avec un autre numero \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&x);
		switch(x)
   	   {
    	case 1: VisualiserContrat();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
	else retour();
		
   
}
int verif_client(char *nom,char *prenom,int* id)
{
   FILE *clients=fopen("clients.bin","rb");
   client c;
   
   while (fread(&c, sizeof(c), 1, clients) != 0 )
      if(strcmp(c.nom, nom) == 0 && strcmp(c.prenom, prenom)==0)
      {
      	*id=c.idClient;
        fclose(clients);
        return 1;
      }
    fclose(clients);
    return 0;
}
int verif_voiture(voiture v)
{
	FILE *voitures=fopen("voitures.bin","rb");
	voiture voit;
	while (fread(&voit,sizeof(voiture),1,voitures) != 0)
	  if(strcmp(voit.marque,v.marque)==0 && strcmp(voit.nomVoiture,v.nomVoiture)==0 && strcmp(voit.couleur,v.couleur)==0 && voit.nbplaces==v.nbplaces && voit.prixJour==v.prixJour)
	  {
	    fclose(voitures);
	    return 1;
	  }
	fclose(voitures);
	return 0;
}
int verif_dispo_voiture(voiture v,int* idV)
{
	FILE *voitures=fopen("voitures.bin","rb");
	voiture voit;
	while (fread(&voit,sizeof(voiture),1,voitures) != 0)
	  if(strcmp(voit.marque,v.marque)==0 && strcmp(voit.nomVoiture,v.nomVoiture)==0 && strcmp(voit.couleur,v.couleur)==0 && voit.nbplaces==v.nbplaces && voit.prixJour==v.prixJour && strcmp(voit.Enlocation,"non")==0)
	  { 
		fseek(voitures,0,SEEK_SET);
	    FILE *tmp=fopen("tmp.bin","wb");
	    while (fread(&voit,sizeof(voiture),1,voitures) != 0){
	    	if(strcmp(voit.marque,v.marque)==0 && strcmp(voit.nomVoiture,v.nomVoiture)==0 && strcmp(voit.couleur,v.couleur)==0 && voit.nbplaces==v.nbplaces && voit.prixJour==v.prixJour && strcmp(voit.Enlocation,"non")==0)
	    	{
	    		*idV=voit.idVoiture;
	    		strcpy(voit.Enlocation,"oui");
	    		fwrite(&voit,sizeof(voit),1,tmp);
    		}
    		else  fwrite(&voit,sizeof(voit),1,tmp);
        }
		fclose(tmp);
		fclose(voitures);
	    remove("voitures.bin");
    	rename("tmp.bin","voitures.bin");
		return 1;	
	  }	
	fclose(voitures);
	return 0;
}
void LouerVoiture()
{
	system("cls");
	contrat cnt;
	client c;
	float num;
	//infos sur le client
	char nom[20],prenom[20];
	voiture v;
	int x,idc,idv,a;
    printf("Saisissez votre nom: ");
    fflush(stdin);
    gets(nom);
    printf("Saisissez votre prenom: ");
	gets(prenom);
	//V�rification du client
    if((a=verif_client(nom,prenom,&idc))==0)
    {
    	printf("\n\n%s %s ne correspond a aucun client. On vous invite a enregistrer vos proppres informations a travers le menu 'Gesion clients'\n",nom,prenom);
    	printf("\nTapper : 1- Pour enregister vos informations\n");
    	printf("         0- Quitter");
    	printf("\n    Votre choix: ");
    	scanf("%d",&x);
    	if(x) 
    	{
			FILE *clients=fopen("clients.bin","ab+") ;
    		int x;
    		system("cls");
			printf("Saisir les informations :\n");
            printf("ID: ");
            scanf("%d",&c.idClient);
            idc=c.idClient;
			strcpy(c.nom,nom);
			strcpy(c.prenom,prenom);
			printf("CIN: ");
			scanf("%d",&c.cin);
			printf("Adresse: ");
			scanf("%s",c.adresse);
			printf("telepphone: ");
			scanf("%d",&c.telephone);
			fwrite(&c,sizeof(client),1,clients);
			fclose(clients);
		}
		else goto stop;
	}
    //infos + verification :voiture
        demande:
        system("cls");
    	printf("Saisir les informations sur la voiture que vous souhaitez louer:\n\n");
        printf("La marque: ");
        scanf("%s",v.marque);
		printf("Le nom de la voiture: ");
        scanf("%s",v.nomVoiture);
        printf("La couleur: ");
        scanf("%s",v.couleur);
        printf("Nombre de places: ");
        scanf("%d",&v.nbplaces);
    	printf("Prix par jour: ");
    	scanf("%d",&v.prixJour);
    	if(!verif_voiture(v))
    	{
    		printf("\n\nAucune voiture ne repond a ses criteres.Voulez vous demander une autre voiture?\n");
    		printf("      1- OUI                   0-NON\n");
    		printf("    Votre choix:  ");
    		scanf("%d",&x);
    		if(x){system("cls");
			goto demande;
		    }
    		else goto quitter;
		}
        
	//V�rification de la disponsibilit� de la voiture
	if(verif_dispo_voiture(v,&idv))
	{
		printf("\n\nLa voiture est disponible.Veuillez vous saisir les informations necessaires pour creer un contrat:\n");
		FILE *contrats=fopen("contrats.bin","ab+");
		int n;
		printf("Saisir le numero de contrat: ");
		scanf("%f",&cnt.numContrat);
		cnt.idVoiture=idv;
		cnt.idClient=idc;
		printf("Debut date de location:\n");
		do{
		printf("Jour: ");
		scanf("%d",&cnt.debut.jour);
		}while(cnt.debut.jour<0 || cnt.debut.jour>31);
		do{
		printf("Mois: ");
		scanf("%d",&cnt.debut.mois);
		}while(cnt.debut.mois<0 || cnt.debut.mois>12);
		do{
		printf("Annee: ");
		scanf("%d",&cnt.debut.annee);
		}while(cnt.debut.annee<2022);
		printf("Fin date de location:\n");
		do{
		printf("Jour: ");
		scanf("%d",&cnt.fin.jour);
		}while(cnt.fin.jour<0 || cnt.fin.jour>31);
		do{
		printf("Mois: ");
		scanf("%d",&cnt.fin.mois);
		}while(cnt.fin.mois<0 || cnt.fin.mois>12);
		do{
		printf("Annee: ");
		scanf("%d",&cnt.fin.annee);
		}while(cnt.fin.annee<2022);
		//calcul du cout
		n=nbrJ(cnt.debut,cnt.fin);
		cnt.cout=n*v.prixJour;
		fwrite(&cnt,sizeof(cnt),1,contrats);
		fclose(contrats);
		printf("\n\n \xba La location a ete bien effectuee");
		goto quitter;
	}
	else
	{
		printf("\n\nLa voiture n'est pas disponible.Voulez vous demander une autre voiture?\n");
    		printf("      1- OUI                   0-NON\n");
    		printf("    Votre choix:  ");
    		scanf("%d",&x);
    		if(x) goto demande;
    		else goto quitter;
    }
	quitter: retour();
	stop:;	
}
void retournerVoiture(int id)
{
	FILE *voitures=fopen("voitures.bin","rb");
	FILE *tmpv=fopen("tmpv.bin","wb");
	int trouve=0,x,condition=1;id;
	voiture voit;

	while (fread(&voit,sizeof(voiture),1,voitures) != 0)
	{ 
		if(voit.idVoiture==id && trouve==0)
		{
			if(strcmp(voit.Enlocation,"non")==0){
			fwrite(&voit,sizeof(voit),1,tmpv);
			condition=0;
			trouve=1;
			}
			else{
	    	strcpy(voit.Enlocation,"non");
	    	fwrite(&voit,sizeof(voit),1,tmpv);
	    	trouve=1;
	    	}
    	}
    	else  fwrite(&voit,sizeof(voit),1,tmpv);
	}
	fclose(tmpv);
	fclose(voitures);
	remove("voitures.bin");
    rename("tmpv.bin","voitures.bin");
	//suppression du contrat si l'eperation du retour a ete effectuee
	if(trouve==1 && condition==1)
	{
		FILE *contrats=fopen("contrats.bin","rb");
		FILE *tmpc=fopen("tmpc.bin","wb");
		contrat c;
		while (fread(&c,sizeof(c),1,contrats) != 0)
		if(c.idVoiture!=id)
		  fwrite(&c,sizeof(c),1,tmpc);
		fclose(tmpc);
    	fclose(contrats);
    	remove("contrats.bin");
    	rename("tmpc.bin","contrats.bin");
    	printf("\nL'operation  a ete bien effectuee\n");
	    retour();
	}
	else if(trouve==1 && condition==0)
	{	
		printf("\nLa voiture dont l'ID vaut %d n'est pas en location\n",id);
    	printf("\n\nTapper : 1- Pour essayer de nouveau si vous avez trompe d'ID \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&x);
		switch(x)
    	{
    	case 1:
		system("cls"); 
		printf("Saisir l'ID de la voiture: ");
    	scanf("%d",&id);
		retournerVoiture(id);
		break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
	else
	{
		printf("\nIl existe aucune voiture dont l'ID vaut %d\n",id);
    	printf("\n\nTapper : 1- Pour essayer avec un autre ID \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&x);
		switch(x)
    	{
    	case 1:printf("Saisir l'ID de la voiture:");
    	scanf("%d",&id);
		retournerVoiture(id);
		break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
}
void modifierContrat()
{
	system("cls");
	FILE *contrats=fopen("contrats.bin","rb");
	FILE *tmp=fopen("tmp.bin","wb");
	FILE *voitures=fopen("voitures.bin","rb");//utiliser si on change date fin location
	voiture voit;
	int trouve=0,x,n,w;
	float num;
	contrat c;
	printf("Saisir le numero de contrat que vous voulez modifier: ");
	scanf("%f",&num);
	while (fread(&c,sizeof(c),1,contrats) != 0)
	{ 
		if(c.numContrat==num && trouve==0)
		{
			do{
			  printf("Choisir l'information que vous voulez modifier:\n");
	          printf("1- Numero du contrat \n");	
              printf("2- Date fin de location\n");
	          printf("0- Retour \n");
	          printf("     Votre choix: ");
              scanf("%d",&x);
              switch(x)
			   {
			  	case 1:
				  printf("Saisir le nouveau numero de contrat : ");
			  	  scanf("%f",&c.numContrat);
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	case 2:
			      printf("Saisir la nouvelle date :\n");
			      printf("Jour: ");
				  scanf("%d",&c.fin.jour);
			      printf("Mois: ");
	        	  scanf("%d",&c.fin.mois);
		          printf("Annee: ");
	          	  scanf("%d",&c.fin.annee);
	          	  //modification du cout
	          	  n=nbrJ(c.debut,c.fin);//nouveau nombre de jour
	          	  //recuperation du prix par jour
				  while (fread(&voit,sizeof(voiture),1,voitures) != 0 && c.idVoiture!=voit.idVoiture);
	          	  c.cout=n*voit.prixJour;
			  	  printf("\n\nVoulez vous changer une autre information?\n");
			  	  printf("      1-OUI                      0-NON \n");
			  	  printf("      Votre choix:  ");
			  	  scanf("%d",&w);
			  	  if(!w)
			  	  goto label;
			  	  system("cls");
			  	  break;
			  	default : break;
			   }
              }while(x>0 && x<3);
            label:
			fwrite(&c,sizeof(c),1,tmp);
		    trouve=1;
	   }
	   else fwrite(&c,sizeof(c),1,tmp);
    }
    
	fclose(tmp);
    fclose(contrats);
    remove("contrats.bin");
    rename("tmp.bin","contrats.bin");
    fclose(voitures);
    if(trouve==0)
	{
        printf("Le numero de contrat saisi est invalide\n");
        printf("\n\nTapper : 1- Pour essayer avec un autre numero \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&w);
		switch(w)
   	   {
    	case 1: modifierContrat();break;
    	case 2: break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
	else{
	if(x!=0){//quant l'utilisateur choisi 6, c-a-d retour , on sort sans rien afficher
	printf("\n\xbaLes modification ont ete bien effectuees\n");
	retour();
	}}
}
void SuppContrat()
{
	system("cls");
	FILE *contrats=fopen("contrats.bin","rb");
	int trouve=0,x;
	float num;
	contrat c;
	printf("Saisir le numero du contrat que vous voulez supprimer: ");
	scanf("%f",&num);
	while (fread(&c,sizeof(c),1,contrats) != 0)
		if(c.numContrat==num) trouve=1;
	fclose(contrats);
	if(trouve==0)	
	{
		printf("\nIl existe aucune contrat qui correspend au numero  %.2f\n",num);
    	printf("\n\nTapper : 1- Pour essayer avec un autre numero \n");
    	printf("         2- Pour retourner au menu \n");
    	printf("         0- Pour quitter l'application");
    	printf("\n              Votre choix: ");
    	scanf("%d",&x);
		switch(x)
    	{
    	case 1: SuppContrat();break;
    	case 2: goto stop;break;
    	case 0: quitter();break;
    	default:;break; 
		}
	}
	//si le contrat existe , on verifie d'abord si la voiture est retourne
	else
	{
		FILE *voitures=fopen("voitures.bin","rb");
		voiture voit;
		while (fread(&voit,sizeof(voiture),1,voitures))
		{
			if(voit.idVoiture==c.idVoiture)
			{
				if(strcmp(voit.Enlocation,"non")!=0)
				{
					printf("\nLa suppresion du contrat n'est pas possible puisque la voiture n'a pas ete encore retournee.IL faut d'abord retourner la voiture\n");
					printf("   1-Continue         0-Retour\n");
					printf("       Votre choix:  ");
					scanf("%d",&x);
					if(x==1)
					{
				 		fclose(voitures);
				 		retournerVoiture(voit.idVoiture);
					}
					else 
					{
						fclose(voitures);
						goto stop;
					}
			    }
		    	else//si la voiture est retournee , on supprime directement le contrat
				{
		   			FILE *contrats=fopen("contrats.bin","rb");
					FILE *tmpc=fopen("tmpc.bin","wb");
					contrat c;
					while (fread(&c,sizeof(c),1,contrats) != 0)
					if(c.idVoiture!=voit.idVoiture)
		  			fwrite(&c,sizeof(c),1,tmpc);
    				fclose(tmpc);
    				fclose(contrats);
    				remove("contrats.bin");
    				rename("tmpc.bin","contrats.bin");
		    	}
			}
		}
	}
	stop:;
}

int main()
{
	int x,a,b,c,id;

	do{
	x=menu();
	switch (x)
	{
    case 1: 
    do{
	a=location();
	switch (a)
	{
    case 1:VisualiserContrat();
	break;
	case 2:LouerVoiture();
	break;	
    case 3:
    system("cls");
	printf("Saisir l'ID de la voiture que vous voulez retourner: ");
	scanf("%d",&id);
	retournerVoiture(id);
	break;	
    case 4:modifierContrat();
	break;	
    case 5:SuppContrat();
	break;
	case 6:break;
	default: printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 6\n");
	system("pause");
	break; 	
    }
    }while(a!=6);
	break;
	case 2:
	do{
    b=gestionVoiture();
	switch (b)
	{
    case 1:listeVoitures();
	break;
	case 2:	ajouterVoiture();break;	
    case 3:modifierVoiture();
	break;	
    case 4:SuppVoiture();
	break;
	case 5:break;	
	default:printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 5\n");
	system("pause");
	break;
    }
    }while(b!=5);
	break;	
    case 3:
    label:
    do{
	c=gestionClient();
    switch(c)
	{
    case 1:listeClients();
	break;
	case 2:ajouterClient();
	break;	
    case 3:modifierClient();
	break;	
    case 4:SuppClient();
	break;
	case 5:break;	
	default:printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 5\n");
	system("pause");
	break;
    }
	}while(c!=5);
	break;
	case 4:break;	
	default:
	printf("\nChoix errone!\nVotre choix doit etre compris entre 1 et 4\n");
	system("pause"); break;	
    }
    }while(x!=4);

	return 0;
}

